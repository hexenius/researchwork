/*
-- Query: SELECT * FROM project.comp1
LIMIT 0, 1000

-- Date: 2022-08-26 17:33
*/
INSERT INTO `` (`id`,`knarea`) VALUES (0,'Social Issues and Professional Practice');
INSERT INTO `` (`id`,`knarea`) VALUES (1,'Security Policy and Managements');
INSERT INTO `` (`id`,`knarea`) VALUES (2,'Management and Leadership');
INSERT INTO `` (`id`,`knarea`) VALUES (3,'Enterprise Architecture');
INSERT INTO `` (`id`,`knarea`) VALUES (4,'Project Management');
INSERT INTO `` (`id`,`knarea`) VALUES (5,'User Experience Design');
INSERT INTO `` (`id`,`knarea`) VALUES (6,'Security Issues and Principles');
INSERT INTO `` (`id`,`knarea`) VALUES (7,'Systems Analysis & Design');
INSERT INTO `` (`id`,`knarea`) VALUES (8,'Requirements Analysis and Specification');
INSERT INTO `` (`id`,`knarea`) VALUES (9,'Data and Information Management');
INSERT INTO `` (`id`,`knarea`) VALUES (10,'Virtual Systems and Services');
INSERT INTO `` (`id`,`knarea`) VALUES (11,'Intelligent Systems (AI)');
INSERT INTO `` (`id`,`knarea`) VALUES (12,'Internet of Things');
INSERT INTO `` (`id`,`knarea`) VALUES (13,'Parallel and Distributed Computing');
INSERT INTO `` (`id`,`knarea`) VALUES (14,'Computer Networks');
INSERT INTO `` (`id`,`knarea`) VALUES (15,'Integrated Systems Technology');
INSERT INTO `` (`id`,`knarea`) VALUES (16,'Platform Technologies');
INSERT INTO `` (`id`,`knarea`) VALUES (17,'Security Technology and Implementation');
INSERT INTO `` (`id`,`knarea`) VALUES (18,'Software Quality, Verification and Valid');
INSERT INTO `` (`id`,`knarea`) VALUES (19,'Software Process');
INSERT INTO `` (`id`,`knarea`) VALUES (20,'Software Modeling and Analysis');
INSERT INTO `` (`id`,`knarea`) VALUES (21,'Software Design');
INSERT INTO `` (`id`,`knarea`) VALUES (22,'Platform-Based Development');
INSERT INTO `` (`id`,`knarea`) VALUES (23,'Graphics and Visualization');
INSERT INTO `` (`id`,`knarea`) VALUES (24,'Operating Systems');
INSERT INTO `` (`id`,`knarea`) VALUES (25,'Data Structures, Algorithms and Complexity');
INSERT INTO `` (`id`,`knarea`) VALUES (26,'Programming Languages');
INSERT INTO `` (`id`,`knarea`) VALUES (27,'Programming Fundamentals');
INSERT INTO `` (`id`,`knarea`) VALUES (28,'Computing Systems Fundamentals');
INSERT INTO `` (`id`,`knarea`) VALUES (29,'Architecture and Organization');
INSERT INTO `` (`id`,`knarea`) VALUES (30,'Digital Design');
INSERT INTO `` (`id`,`knarea`) VALUES (31,'Circuits and Electronics');
INSERT INTO `` (`id`,`knarea`) VALUES (32,'Signal Processing');
INSERT INTO `` (`id`,`knarea`) VALUES (33,'Embedded Systems');
