/*
-- Query: SELECT * FROM project.admin
LIMIT 0, 1000

-- Date: 2022-08-26 17:32
*/
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (0,'Social Issues and Professional Practice','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (1,'Security Policy and Managements','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (2,'Management and Leadership','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (3,'Enterprise Architecture','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (4,'Project Management','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (5,'User Experience Design','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (6,'Security Issues and Principles','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (7,'Systems Analysis & Design','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (8,'Requirements Analysis and Specification','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (9,'Data and Information Management','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (10,'Virtual Systems and Services','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (11,'Intelligent Systems (AI)','Found','Not Found','Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (12,'Internet of Things','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (13,'Parallel and Distributed Computing','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (14,'Computer Networks','Found','Found','Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (15,'Integrated Systems Technology','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (16,'Platform Technologies','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (17,'Security Technology and Implementation','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (18,'Software Quality, Verification and Valid','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (19,'Software Process','Found','Found','Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (20,'Software Modeling and Analysis','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (21,'Software Design','Found','Found','Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (22,'Platform-Based Development','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (23,'Graphics and Visualization','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (24,'Operating Systems','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (25,'Data Structures, Algorithms and Complexi','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (26,'Programming Languages','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (27,'Programming Fundamentals','Found','Found','Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (28,'Computing Systems Fundamentals','Found','Found','Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (29,'Architecture and Organization','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (30,'Digital Design','Found','Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (31,'Circuits and Electronics','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (32,'Signal Processing','Found','Not Found','Not Found');
INSERT INTO `` (`id`,`knarea`,`sppu`,`PCCOE`,`batu`) VALUES (33,'Embedded Systems','Found','Not Found','Not Found');
