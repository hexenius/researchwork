/*
-- Query: SELECT * FROM project.comp
LIMIT 0, 1000

-- Date: 2022-08-26 17:32
*/
INSERT INTO `` (`knarea`) VALUES ('Architecture and Organization');
INSERT INTO `` (`knarea`) VALUES ('Circuits and Electronics');
INSERT INTO `` (`knarea`) VALUES ('Computer Networks');
INSERT INTO `` (`knarea`) VALUES ('Computing Systems Fundamentals');
INSERT INTO `` (`knarea`) VALUES ('Data and Information Management');
INSERT INTO `` (`knarea`) VALUES ('Data Structures, Algorithms and Complexi');
INSERT INTO `` (`knarea`) VALUES ('Digital Design');
INSERT INTO `` (`knarea`) VALUES ('Embedded Systems');
INSERT INTO `` (`knarea`) VALUES ('Enterprise Architecture');
INSERT INTO `` (`knarea`) VALUES ('Graphics and Visualization');
INSERT INTO `` (`knarea`) VALUES ('Integrated Systems Technology');
INSERT INTO `` (`knarea`) VALUES ('Intelligent Systems (AI)');
INSERT INTO `` (`knarea`) VALUES ('Internet of Things');
INSERT INTO `` (`knarea`) VALUES ('Management and Leadership');
INSERT INTO `` (`knarea`) VALUES ('Operating Systems');
INSERT INTO `` (`knarea`) VALUES ('Parallel and Distributed Computing');
INSERT INTO `` (`knarea`) VALUES ('Platform Technologies');
INSERT INTO `` (`knarea`) VALUES ('Platform-Based Development');
INSERT INTO `` (`knarea`) VALUES ('Programming Fundamentals');
INSERT INTO `` (`knarea`) VALUES ('Programming Languages');
INSERT INTO `` (`knarea`) VALUES ('Project Management');
INSERT INTO `` (`knarea`) VALUES ('Requirements Analysis and Specification');
INSERT INTO `` (`knarea`) VALUES ('Security Issues and Principles');
INSERT INTO `` (`knarea`) VALUES ('Security Policy and Managements');
INSERT INTO `` (`knarea`) VALUES ('Security Technology and Implementation');
INSERT INTO `` (`knarea`) VALUES ('Signal Processing');
INSERT INTO `` (`knarea`) VALUES ('Social Issues and Professional Practice');
INSERT INTO `` (`knarea`) VALUES ('Software Design');
INSERT INTO `` (`knarea`) VALUES ('Software Modeling and Analysis');
INSERT INTO `` (`knarea`) VALUES ('Software Process');
INSERT INTO `` (`knarea`) VALUES ('Software Quality, Verification and Valid');
INSERT INTO `` (`knarea`) VALUES ('Systems Analysis & Design');
INSERT INTO `` (`knarea`) VALUES ('User Experience Design');
INSERT INTO `` (`knarea`) VALUES ('Virtual Systems and Services');
