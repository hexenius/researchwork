/*
-- Query: SELECT * FROM project.industry
LIMIT 0, 1000

-- Date: 2022-08-26 17:33
*/
INSERT INTO `` (`domain`,`req`) VALUES ('java','Knowledge of latset java versions features,Spring framework: Core, Boot, MVC, Security, Rest, Web service, JDBC persistence using MySQL/RDS and Hibernate,\nKnowledge of Micro services concepts, Modern Core Java Concurrency, Database: SQL CRUD operations, Building and managing REST APIs, GIT, Maven, JavaScript, AJAX, JSON Binding with Java using Google GSON, Knowledge of Linux');
