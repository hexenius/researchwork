/*
-- Query: SELECT * FROM project.top
LIMIT 0, 1000

-- Date: 2022-08-26 17:33
*/
INSERT INTO `` (`clgname`,`avg`) VALUES ('PCCOE',0.814988);
INSERT INTO `` (`clgname`,`avg`) VALUES ('sppu',0.816841);
